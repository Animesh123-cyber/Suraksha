import React from 'react';
import { ScanResult, Finding } from '../types/cspm';
import { ShieldAlert, ShieldCheck, ArrowRight, AlertTriangle, FileCode } from 'lucide-react';

interface DashboardViewProps {
  scanResult: ScanResult;
  onSelectFinding: (finding: Finding) => void;
  onNavigateToScanner: () => void;
  onNavigateToVerifier: () => void;
  onNavigateToCompliance: () => void;
  onNavigateToWebhooks: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  scanResult,
  onSelectFinding,
  onNavigateToScanner,
  onNavigateToVerifier,
  onNavigateToCompliance,
  onNavigateToWebhooks,
}) => {
  const { summary, findings, compliance } = scanResult;

  const scoreColor =
    summary.postureScore >= 80
      ? 'text-emerald-400'
      : summary.postureScore >= 50
      ? 'text-amber-400'
      : 'text-rose-500';

  const scoreRingColor =
    summary.postureScore >= 80
      ? 'border-emerald-500/50'
      : summary.postureScore >= 50
      ? 'border-amber-500/50'
      : 'border-rose-500/50';

  const postureStatusText =
    summary.postureScore >= 80
      ? 'Compliant & Hardened'
      : summary.postureScore >= 50
      ? 'Moderate Security Deficits'
      : 'Critical Security Deficits';

  return (
    <div className="space-y-6">
      {/* Top Banner / Hero Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Posture Score Card */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-300">Security Posture Score</h2>
              <div className="text-xs text-slate-500 mt-0.5">Based on CIS AWS & DevSecOps benchmarks</div>
            </div>
            <span
              className={`text-xs font-medium px-2 py-0.5 rounded border ${
                summary.postureScore >= 80
                  ? 'border-emerald-500/30 text-emerald-400 bg-emerald-950/30'
                  : summary.postureScore >= 50
                  ? 'border-amber-500/30 text-amber-400 bg-amber-950/30'
                  : 'border-rose-500/30 text-rose-400 bg-rose-950/30'
              }`}
            >
              {postureStatusText}
            </span>
          </div>

          <div className="my-6 flex items-center justify-center">
            <div className={`w-32 h-32 rounded-full border-4 ${scoreRingColor} flex flex-col items-center justify-center bg-slate-950/80`}>
              <span className={`text-4xl font-mono font-bold tabular-nums ${scoreColor}`}>
                {summary.postureScore}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ 100</span>
            </div>
          </div>

          <div className="text-xs text-slate-400 flex items-center justify-between border-t border-slate-800/80 pt-3">
            <span>Target: <span className="font-mono text-slate-300">{summary.scannedFile}</span></span>
            <span className="tabular-nums font-mono text-slate-500">{summary.scanDurationMs}ms</span>
          </div>
        </div>

        {/* 4-KPI Metric Strip */}
        <div className="lg:col-span-2 bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-300">Posture Breakdown</h2>
              <div className="text-xs text-slate-500">Resource health & vulnerability severity spectrum</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={onNavigateToVerifier}
                className="text-xs text-cyan-300 hover:text-cyan-200 flex items-center gap-1 font-semibold bg-cyan-950/60 border border-cyan-700/60 px-2.5 py-1 rounded transition-colors"
              >
                Enter Data & Verify <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={onNavigateToScanner}
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 font-medium py-1 px-1.5"
              >
                IaC Scanner <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-2">
            <div className="bg-slate-950/60 border border-rose-900/40 rounded p-3">
              <div className="text-xs text-rose-400 font-medium">Critical</div>
              <div className="text-2xl font-mono font-bold text-rose-400 mt-1 tabular-nums">
                {summary.criticalCount}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Immediate Breach Risk</div>
            </div>

            <div className="bg-slate-950/60 border border-amber-900/40 rounded p-3">
              <div className="text-xs text-amber-400 font-medium">High</div>
              <div className="text-2xl font-mono font-bold text-amber-400 mt-1 tabular-nums">
                {summary.highCount}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Compliance Violations</div>
            </div>

            <div className="bg-slate-950/60 border border-yellow-900/40 rounded p-3">
              <div className="text-xs text-yellow-400 font-medium">Medium</div>
              <div className="text-2xl font-mono font-bold text-yellow-400 mt-1 tabular-nums">
                {summary.mediumCount}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Configuration Deficits</div>
            </div>

            <div className="bg-slate-950/60 border border-emerald-900/40 rounded p-3">
              <div className="text-xs text-emerald-400 font-medium">Passed Checks</div>
              <div className="text-2xl font-mono font-bold text-emerald-400 mt-1 tabular-nums">
                {summary.passedCount}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Compliant Rules</div>
            </div>
          </div>

          {/* Quick Automation Alert CTA */}
          <div className="border-t border-slate-800/80 pt-3 mt-3 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Total Audited Resources: <strong className="text-slate-200 font-mono">{summary.totalResources}</strong>
            </span>
            <button
              onClick={onNavigateToWebhooks}
              className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1.5 transition-colors"
            >
              Configure Automated Webhook Alerts <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Compliance Frameworks Scorecards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-200">Compliance Framework Readiness</h2>
          <button
            onClick={onNavigateToCompliance}
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
          >
            Detailed Compliance Matrix <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {compliance.map((c) => {
            const passPct = c.scorePercentage;
            const barColor =
              passPct >= 80 ? 'bg-emerald-500' : passPct >= 50 ? 'bg-amber-500' : 'bg-rose-500';
            const textColor =
              passPct >= 80 ? 'text-emerald-400' : passPct >= 50 ? 'text-amber-400' : 'text-rose-400';

            return (
              <div
                key={c.name}
                onClick={onNavigateToCompliance}
                className="bg-slate-900/60 border border-slate-800 hover:border-slate-700 rounded-lg p-4 cursor-pointer transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="text-sm font-semibold text-slate-200">{c.name}</div>
                  <span className={`text-sm font-mono font-bold tabular-nums ${textColor}`}>
                    {c.scorePercentage}%
                  </span>
                </div>
                <div className="text-xs text-slate-500 mt-0.5">{c.version}</div>

                <div className="w-full bg-slate-950 rounded-full h-1.5 mt-3.5 overflow-hidden">
                  <div className={`h-full rounded-full ${barColor}`} style={{ width: `${passPct}%` }} />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 mt-2 font-mono">
                  <span>{c.passedControls} passed</span>
                  <span className={c.failedControls > 0 ? 'text-rose-400' : 'text-slate-500'}>
                    {c.failedControls} failed
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Top Security Findings List */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-200">Active Vulnerabilities & Misconfigurations</h2>
            <div className="text-xs text-slate-500">Click any finding to inspect line snippet, CVSS impact, and 1-click remediation</div>
          </div>
          <button
            onClick={onNavigateToScanner}
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
          >
            Inspect in IaC Editor <FileCode className="w-3.5 h-3.5" />
          </button>
        </div>

        {findings.length === 0 ? (
          <div className="py-10 text-center text-slate-400">
            <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
            <div className="text-sm font-semibold text-white">Zero Security Misconfigurations Detected</div>
            <div className="text-xs text-slate-500 mt-1">All scanned cloud resources comply with active security policies.</div>
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {findings.slice(0, 6).map((finding) => (
              <div
                key={finding.id}
                onClick={() => {
                  onSelectFinding(finding);
                  onNavigateToScanner();
                }}
                className="py-3 flex items-start justify-between gap-4 hover:bg-slate-800/40 px-2 rounded cursor-pointer transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                        finding.severity === 'CRITICAL'
                          ? 'bg-rose-950/60 border-rose-800 text-rose-300'
                          : finding.severity === 'HIGH'
                          ? 'bg-amber-950/60 border-amber-800 text-amber-300'
                          : 'bg-yellow-950/60 border-yellow-800 text-yellow-300'
                      }`}
                    >
                      {finding.severity}
                    </span>
                    <span className="text-sm font-semibold text-slate-200">{finding.title}</span>
                  </div>
                  <div className="text-xs text-slate-400 line-clamp-1">{finding.impact}</div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 font-mono">
                    <span>Target: <span className="text-cyan-400">{finding.resourceType}.{finding.resourceName}</span></span>
                    <span>Line: <span className="text-slate-300">{finding.lineNumber}</span></span>
                    <span>CVSS: <span className="text-slate-300">{finding.cvssScore}</span></span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="text-xs text-slate-400 group-hover:text-cyan-400 flex items-center gap-1">
                    Fix <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
