import React, { useState } from 'react';
import { runCspmScan } from '../lib/complianceEngine';
import { ScanResult, Finding } from '../types/cspm';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  ArrowRight,
  Terminal,
  Code2,
  Sparkles,
  RefreshCw,
  Sliders,
} from 'lucide-react';

interface DataVerifierViewProps {
  onLoadIntoScanner: (code: string, fileName: string) => void;
}

type ServiceType = 's3' | 'security_group' | 'iam' | 'rds' | 'ec2' | 'cloudtrail';

export const DataVerifierView: React.FC<DataVerifierViewProps> = ({ onLoadIntoScanner }) => {
  const [entryMode, setEntryMode] = useState<'form' | 'raw'>('form');
  const [serviceType, setServiceType] = useState<ServiceType>('s3');

  // Form State for S3
  const [s3Data, setS3Data] = useState({
    bucketName: 'customer-data-vault',
    acl: 'public-read', // default to insecure to let user verify & fix
    blockPublicAccess: 'disabled', // 'all_blocked' | 'disabled'
    encryption: 'disabled', // 'kms' | 'aes256' | 'disabled'
    versioning: false,
  });

  // Form State for Security Group
  const [sgData, setSgData] = useState({
    sgName: 'web-inbound-sg',
    port: '22',
    protocol: 'tcp',
    cidr: '0.0.0.0/0',
    description: 'Inbound management rule',
  });

  // Form State for IAM
  const [iamData, setIamData] = useState({
    policyName: 'service-execution-policy',
    action: '*',
    resource: '*',
    attachAdminManaged: false,
  });

  // Form State for RDS
  const [rdsData, setRdsData] = useState({
    identifier: 'primary-customer-db',
    engine: 'postgres',
    storageEncrypted: false,
    publiclyAccessible: true,
    hardcodedPassword: true,
  });

  // Form State for EC2
  const [ec2Data, setEc2Data] = useState({
    instanceName: 'api-worker-node-01',
    imdsTokens: 'optional', // 'required' | 'optional'
    associatePublicIp: false,
  });

  // Form State for CloudTrail
  const [trailData, setTrailData] = useState({
    trailName: 'organization-audit-trail',
    multiRegion: false,
    logFileValidation: false,
  });

  // Raw Input State
  const [rawCodeInput, setRawCodeInput] = useState<string>(
`resource "aws_s3_bucket" "my_custom_bucket" {
  bucket = "user-entered-bucket-2026"
  acl    = "public-read"
}

resource "aws_security_group" "custom_firewall" {
  name = "custom-inbound-sg"
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}`
  );

  // Verification Results
  const [verificationResult, setVerificationResult] = useState<ScanResult | null>(() => {
    // Initial verification of default S3
    const initialHcl = generateHclForService('s3', {
      bucketName: 'customer-data-vault',
      acl: 'public-read',
      blockPublicAccess: 'disabled',
      encryption: 'disabled',
      versioning: false,
    });
    return runCspmScan(initialHcl, 'verified_resource.tf');
  });

  const [copiedHcl, setCopiedHcl] = useState(false);
  const [copiedBoto3, setCopiedBoto3] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  // Helper to generate HCL from form state
  function generateHclForService(type: ServiceType, data: any): string {
    if (type === 's3') {
      const parts = [
`resource "aws_s3_bucket" "${data.bucketName || 'target_bucket'}" {
  bucket = "${data.bucketName || 'target_bucket'}"
  acl    = "${data.acl}"
}`
      ];

      if (data.blockPublicAccess === 'all_blocked') {
        parts.push(
`resource "aws_s3_bucket_public_access_block" "${data.bucketName}_block" {
  bucket = aws_s3_bucket.${data.bucketName || 'target_bucket'}.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}`
        );
      }

      if (data.encryption === 'kms') {
        parts.push(
`resource "aws_s3_bucket_server_side_encryption_configuration" "${data.bucketName}_sse" {
  bucket = aws_s3_bucket.${data.bucketName || 'target_bucket'}.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}`
        );
      } else if (data.encryption === 'aes256') {
        parts.push(
`resource "aws_s3_bucket_server_side_encryption_configuration" "${data.bucketName}_sse" {
  bucket = aws_s3_bucket.${data.bucketName || 'target_bucket'}.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}`
        );
      }

      return parts.join('\n\n');
    }

    if (type === 'security_group') {
      return `resource "aws_security_group" "${data.sgName || 'app_sg'}" {
  name        = "${data.sgName || 'app_sg'}"
  description = "${data.description || 'Firewall rule'}"

  ingress {
    from_port   = ${data.port}
    to_port     = ${data.port}
    protocol    = "${data.protocol}"
    cidr_blocks = ["${data.cidr}"]
  }
}`;
    }

    if (type === 'iam') {
      const parts = [
`resource "aws_iam_policy" "${data.policyName || 'scoped_policy'}" {
  name = "${data.policyName || 'scoped_policy'}"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ${data.action === '*' ? '"*"' : JSON.stringify(data.action.split(',').map((s: string) => s.trim()))}
        Resource = "${data.resource}"
      }
    ]
  })
}`
      ];

      if (data.attachAdminManaged) {
        parts.push(
`resource "aws_iam_role_policy_attachment" "admin_attach" {
  role       = "worker-role"
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}`
        );
      }

      return parts.join('\n\n');
    }

    if (type === 'rds') {
      return `resource "aws_db_instance" "${data.identifier || 'db_instance'}" {
  identifier          = "${data.identifier || 'db_instance'}"
  engine              = "${data.engine}"
  storage_encrypted   = ${data.storageEncrypted ? 'true' : 'false'}
  publicly_accessible = ${data.publiclyAccessible ? 'true' : 'false'}
  allocated_storage   = 50
  instance_class      = "db.t3.medium"
  ${data.hardcodedPassword ? 'password = "PlaintextPassword123!"' : 'password = var.db_password # Injected safely'}
}`;
    }

    if (type === 'ec2') {
      return `resource "aws_instance" "${data.instanceName || 'web_node'}" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t3.medium"
  ${data.associatePublicIp ? 'associate_public_ip_address = true' : ''}

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "${data.imdsTokens}"
  }
}`;
    }

    if (type === 'cloudtrail') {
      return `resource "aws_cloudtrail" "${data.trailName || 'main_trail'}" {
  name                       = "${data.trailName || 'main_trail'}"
  s3_bucket_name             = "audit-logs-bucket"
  is_multi_region_trail      = ${data.multiRegion ? 'true' : 'false'}
  enable_log_file_validation = ${data.logFileValidation ? 'true' : 'false'}
}`;
    }

    return '';
  }

  // Trigger Verification
  const handleVerify = () => {
    setIsVerifying(true);
    let codeToVerify = '';
    let fileName = 'verified_input.tf';

    if (entryMode === 'form') {
      let currentData: any;
      if (serviceType === 's3') currentData = s3Data;
      else if (serviceType === 'security_group') currentData = sgData;
      else if (serviceType === 'iam') currentData = iamData;
      else if (serviceType === 'rds') currentData = rdsData;
      else if (serviceType === 'ec2') currentData = ec2Data;
      else currentData = trailData;

      codeToVerify = generateHclForService(serviceType, currentData);
      fileName = `${serviceType}_config.tf`;
    } else {
      codeToVerify = rawCodeInput;
      fileName = 'custom_raw_input.tf';
    }

    const result = runCspmScan(codeToVerify, fileName);
    setVerificationResult(result);
    setTimeout(() => setIsVerifying(false), 250);
  };

  // Preset Handlers
  const applyPreset = (presetName: string) => {
    if (presetName === 's3_vulnerable') {
      setServiceType('s3');
      setS3Data({
        bucketName: 'public-leaked-s3-bucket',
        acl: 'public-read',
        blockPublicAccess: 'disabled',
        encryption: 'disabled',
        versioning: false,
      });
      const hcl = generateHclForService('s3', {
        bucketName: 'public-leaked-s3-bucket',
        acl: 'public-read',
        blockPublicAccess: 'disabled',
        encryption: 'disabled',
        versioning: false,
      });
      setVerificationResult(runCspmScan(hcl, 's3_vulnerable.tf'));
    } else if (presetName === 's3_hardened') {
      setServiceType('s3');
      setS3Data({
        bucketName: 'enterprise-hardened-vault',
        acl: 'private',
        blockPublicAccess: 'all_blocked',
        encryption: 'kms',
        versioning: true,
      });
      const hcl = generateHclForService('s3', {
        bucketName: 'enterprise-hardened-vault',
        acl: 'private',
        blockPublicAccess: 'all_blocked',
        encryption: 'kms',
        versioning: true,
      });
      setVerificationResult(runCspmScan(hcl, 's3_hardened.tf'));
    } else if (presetName === 'sg_open_ssh') {
      setServiceType('security_group');
      setSgData({
        sgName: 'unrestricted-ssh-sg',
        port: '22',
        protocol: 'tcp',
        cidr: '0.0.0.0/0',
        description: 'Open SSH to world',
      });
      const hcl = generateHclForService('security_group', {
        sgName: 'unrestricted-ssh-sg',
        port: '22',
        protocol: 'tcp',
        cidr: '0.0.0.0/0',
        description: 'Open SSH to world',
      });
      setVerificationResult(runCspmScan(hcl, 'sg_open_ssh.tf'));
    } else if (presetName === 'sg_secure') {
      setServiceType('security_group');
      setSgData({
        sgName: 'private-bastion-sg',
        port: '443',
        protocol: 'tcp',
        cidr: '10.0.0.0/16',
        description: 'Private VPC internal traffic only',
      });
      const hcl = generateHclForService('security_group', {
        sgName: 'private-bastion-sg',
        port: '443',
        protocol: 'tcp',
        cidr: '10.0.0.0/16',
        description: 'Private VPC internal traffic only',
      });
      setVerificationResult(runCspmScan(hcl, 'sg_secure.tf'));
    } else if (presetName === 'iam_wildcard') {
      setServiceType('iam');
      setIamData({
        policyName: 'wildcard-admin-policy',
        action: '*',
        resource: '*',
        attachAdminManaged: true,
      });
      const hcl = generateHclForService('iam', {
        policyName: 'wildcard-admin-policy',
        action: '*',
        resource: '*',
        attachAdminManaged: true,
      });
      setVerificationResult(runCspmScan(hcl, 'iam_wildcard.tf'));
    } else if (presetName === 'rds_unencrypted') {
      setServiceType('rds');
      setRdsData({
        identifier: 'insecure-customer-database',
        engine: 'postgres',
        storageEncrypted: false,
        publiclyAccessible: true,
        hardcodedPassword: true,
      });
      const hcl = generateHclForService('rds', {
        identifier: 'insecure-customer-database',
        engine: 'postgres',
        storageEncrypted: false,
        publiclyAccessible: true,
        hardcodedPassword: true,
      });
      setVerificationResult(runCspmScan(hcl, 'rds_unencrypted.tf'));
    }
  };

  const currentGeneratedHcl =
    entryMode === 'form'
      ? generateHclForService(
          serviceType,
          serviceType === 's3'
            ? s3Data
            : serviceType === 'security_group'
            ? sgData
            : serviceType === 'iam'
            ? iamData
            : serviceType === 'rds'
            ? rdsData
            : serviceType === 'ec2'
            ? ec2Data
            : trailData
        )
      : rawCodeInput;

  const handleCopyHcl = () => {
    navigator.clipboard.writeText(currentGeneratedHcl);
    setCopiedHcl(true);
    setTimeout(() => setCopiedHcl(false), 2000);
  };

  const handleCopyBoto3 = () => {
    if (verificationResult?.findings[0]?.boto3Remediation) {
      navigator.clipboard.writeText(verificationResult.findings[0].boto3Remediation);
      setCopiedBoto3(true);
      setTimeout(() => setCopiedBoto3(false), 2000);
    }
  };

  const isCompliant = (verificationResult?.findings.length || 0) === 0;

  return (
    <div className="space-y-6">
      {/* Header & Mode Switcher */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            Enter Cloud Resource Data & Verify Compliance
          </h2>
          <div className="text-xs text-slate-400 mt-1">
            Configure any AWS cloud resource or enter custom IaC configurations below to immediately verify security posture, CIS benchmark controls, and potential vulnerabilities.
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 p-1 rounded">
          <button
            onClick={() => setEntryMode('form')}
            className={`px-3 py-1.5 text-xs rounded font-medium transition-colors ${
              entryMode === 'form'
                ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Guided Resource Form
          </button>
          <button
            onClick={() => setEntryMode('raw')}
            className={`px-3 py-1.5 text-xs rounded font-medium transition-colors ${
              entryMode === 'raw'
                ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Custom Code / Raw Input
          </button>
        </div>
      </div>

      {/* Preset Quick Test Buttons */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-slate-500 font-medium mr-1 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Quick Presets:
        </span>
        <button
          onClick={() => applyPreset('s3_vulnerable')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-rose-900/60 text-rose-300 rounded transition-colors"
        >
          🚨 Public S3 Bucket
        </button>
        <button
          onClick={() => applyPreset('sg_open_ssh')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-amber-900/60 text-amber-300 rounded transition-colors"
        >
          ⚠️ Open SSH (0.0.0.0/0)
        </button>
        <button
          onClick={() => applyPreset('iam_wildcard')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-rose-900/60 text-rose-300 rounded transition-colors"
        >
          🚨 Wildcard IAM Role
        </button>
        <button
          onClick={() => applyPreset('rds_unencrypted')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-rose-900/60 text-rose-300 rounded transition-colors"
        >
          🚨 Unencrypted RDS
        </button>
        <button
          onClick={() => applyPreset('s3_hardened')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-emerald-900/60 text-emerald-300 rounded transition-colors"
        >
          🛡️ Hardened S3 + KMS
        </button>
        <button
          onClick={() => applyPreset('sg_secure')}
          className="text-xs px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-emerald-900/60 text-emerald-300 rounded transition-colors"
        >
          🛡️ Secure Private SG
        </button>
      </div>

      {/* Main Two-Column Layout: Input Form/Code (Left) & Live Verification Verdict (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Input Form or Raw Code Editor */}
        <div className="lg:col-span-6 bg-slate-900/70 border border-slate-800 rounded-lg p-5 space-y-4">
          {entryMode === 'form' ? (
            <>
              {/* Cloud Service Selector */}
              <div>
                <label className="text-xs text-slate-400 block mb-1.5 font-medium">Select Cloud Resource Type</label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {[
                    { id: 's3', label: 'Amazon S3' },
                    { id: 'security_group', label: 'Security Group' },
                    { id: 'iam', label: 'AWS IAM' },
                    { id: 'rds', label: 'Amazon RDS' },
                    { id: 'ec2', label: 'Amazon EC2' },
                    { id: 'cloudtrail', label: 'CloudTrail' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setServiceType(s.id as ServiceType)}
                      className={`py-2 px-1 text-center text-xs font-medium rounded border transition-colors ${
                        serviceType === s.id
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-semibold'
                          : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Form Fields based on serviceType */}
              {serviceType === 's3' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Bucket Name</label>
                    <input
                      type="text"
                      value={s3Data.bucketName}
                      onChange={(e) => setS3Data({ ...s3Data, bucketName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Bucket Access Control (ACL)</label>
                    <select
                      value={s3Data.acl}
                      onChange={(e) => setS3Data({ ...s3Data, acl: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                    >
                      <option value="private">private (Recommended - Bucket Owner Enforced)</option>
                      <option value="public-read">public-read (CRITICAL - World Readable)</option>
                      <option value="public-read-write">public-read-write (CRITICAL - World Read & Write)</option>
                      <option value="authenticated-read">authenticated-read (Any AWS Account)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">S3 Block Public Access Setting</label>
                    <select
                      value={s3Data.blockPublicAccess}
                      onChange={(e) => setS3Data({ ...s3Data, blockPublicAccess: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                    >
                      <option value="all_blocked">Enabled (All 4 Public Access Controls Enforced)</option>
                      <option value="disabled">Disabled (Allows Public Exposure)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Default Server-Side Encryption (SSE)</label>
                    <select
                      value={s3Data.encryption}
                      onChange={(e) => setS3Data({ ...s3Data, encryption: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                    >
                      <option value="kms">AWS KMS (Customer Managed Key - CIS 2.1.1)</option>
                      <option value="aes256">AES256 (SSE-S3 Default)</option>
                      <option value="disabled">Disabled (Unencrypted At Rest - Violation)</option>
                    </select>
                  </div>
                </div>
              )}

              {serviceType === 'security_group' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Security Group Name</label>
                    <input
                      type="text"
                      value={sgData.sgName}
                      onChange={(e) => setSgData({ ...sgData, sgName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Inbound Port</label>
                      <select
                        value={sgData.port}
                        onChange={(e) => setSgData({ ...sgData, port: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                      >
                        <option value="22">Port 22 (SSH Remote Shell)</option>
                        <option value="3389">Port 3389 (RDP Remote Desktop)</option>
                        <option value="5432">Port 5432 (PostgreSQL Database)</option>
                        <option value="3306">Port 3306 (MySQL Database)</option>
                        <option value="443">Port 443 (HTTPS Secure Web)</option>
                        <option value="80">Port 80 (HTTP Plaintext Web)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Source CIDR Block</label>
                      <select
                        value={sgData.cidr}
                        onChange={(e) => setSgData({ ...sgData, cidr: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                      >
                        <option value="0.0.0.0/0">0.0.0.0/0 (Internet - High Risk)</option>
                        <option value="10.0.0.0/16">10.0.0.0/16 (Private Corporate VPC)</option>
                        <option value="192.168.1.0/24">192.168.1.0/24 (Internal Bastion Subnet)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {serviceType === 'iam' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">IAM Policy Name</label>
                    <input
                      type="text"
                      value={iamData.policyName}
                      onChange={(e) => setIamData({ ...iamData, policyName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Action Permissions</label>
                    <select
                      value={iamData.action}
                      onChange={(e) => setIamData({ ...iamData, action: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    >
                      <option value="*">* (Wildcard - Overly Permissive / CRITICAL)</option>
                      <option value="s3:GetObject, s3:PutObject">s3:GetObject, s3:PutObject (Scoped Least-Privilege)</option>
                      <option value="ec2:DescribeInstances">ec2:DescribeInstances (Read Only)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Target Resource</label>
                    <input
                      type="text"
                      value={iamData.resource}
                      onChange={(e) => setIamData({ ...iamData, resource: e.target.value })}
                      placeholder="* or arn:aws:s3:::bucket/*"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={iamData.attachAdminManaged}
                      onChange={(e) => setIamData({ ...iamData, attachAdminManaged: e.target.checked })}
                      className="rounded border-slate-700 bg-slate-950 text-cyan-400 focus:ring-0"
                    />
                    <span>Attach AWS Managed <code>AdministratorAccess</code> policy (Violates CIS 1.16)</span>
                  </label>
                </div>
              )}

              {serviceType === 'rds' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">DB Instance Identifier</label>
                    <input
                      type="text"
                      value={rdsData.identifier}
                      onChange={(e) => setRdsData({ ...rdsData, identifier: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Storage Encryption</label>
                      <select
                        value={rdsData.storageEncrypted ? 'true' : 'false'}
                        onChange={(e) => setRdsData({ ...rdsData, storageEncrypted: e.target.value === 'true' })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                      >
                        <option value="true">storage_encrypted = true (Encrypted)</option>
                        <option value="false">storage_encrypted = false (Unencrypted - Violation)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Public Accessibility</label>
                      <select
                        value={rdsData.publiclyAccessible ? 'true' : 'false'}
                        onChange={(e) => setRdsData({ ...rdsData, publiclyAccessible: e.target.value === 'true' })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                      >
                        <option value="false">publicly_accessible = false (Private Subnet Only)</option>
                        <option value="true">publicly_accessible = true (Public IP - CRITICAL)</option>
                      </select>
                    </div>
                  </div>

                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={rdsData.hardcodedPassword}
                      onChange={(e) => setRdsData({ ...rdsData, hardcodedPassword: e.target.checked })}
                      className="rounded border-slate-700 bg-slate-950 text-cyan-400 focus:ring-0"
                    />
                    <span>Include hardcoded plaintext master password in config</span>
                  </label>
                </div>
              )}

              {serviceType === 'ec2' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Instance Name</label>
                    <input
                      type="text"
                      value={ec2Data.instanceName}
                      onChange={(e) => setEc2Data({ ...ec2Data, instanceName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">Instance Metadata Service (IMDS)</label>
                    <select
                      value={ec2Data.imdsTokens}
                      onChange={(e) => setEc2Data({ ...ec2Data, imdsTokens: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                    >
                      <option value="required">http_tokens = "required" (IMDSv2 Enforced - CIS 5.6)</option>
                      <option value="optional">http_tokens = "optional" (Vulnerable to SSRF Credential Theft)</option>
                    </select>
                  </div>
                </div>
              )}

              {serviceType === 'cloudtrail' && (
                <div className="space-y-3.5 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">CloudTrail Name</label>
                    <input
                      type="text"
                      value={trailData.trailName}
                      onChange={(e) => setTrailData({ ...trailData, trailName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Multi-Region Logging</label>
                      <select
                        value={trailData.multiRegion ? 'true' : 'false'}
                        onChange={(e) => setTrailData({ ...trailData, multiRegion: e.target.value === 'true' })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                      >
                        <option value="true">Enabled (CIS 3.1)</option>
                        <option value="false">Disabled (Blind spots in unused regions)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 block mb-1">Log File Validation</label>
                      <select
                        value={trailData.logFileValidation ? 'true' : 'false'}
                        onChange={(e) => setTrailData({ ...trailData, logFileValidation: e.target.value === 'true' })}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
                      >
                        <option value="true">Enabled (CIS 3.2 Integrity Digests)</option>
                        <option value="false">Disabled</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Mode 2: Raw Code / JSON / HCL Editor */
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Enter Terraform HCL / Cloud Config to verify:</span>
                <button
                  onClick={() => setRawCodeInput('')}
                  className="text-[11px] text-slate-500 hover:text-slate-300"
                >
                  Clear Editor
                </button>
              </div>
              <textarea
                value={rawCodeInput}
                onChange={(e) => setRawCodeInput(e.target.value)}
                placeholder="resource 'aws_s3_bucket' 'my_bucket' { ... }"
                spellCheck={false}
                rows={16}
                className="w-full bg-slate-950 border border-slate-800 rounded p-3 text-xs font-mono text-slate-200 outline-none focus:border-cyan-400 resize-none leading-relaxed"
              />
            </div>
          )}

          {/* Action Button: Verify Security Posture */}
          <div className="pt-2">
            <button
              onClick={handleVerify}
              disabled={isVerifying}
              className="w-full py-2.5 px-4 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-xs rounded transition-colors flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
              Verify Security Posture Now
            </button>
          </div>
        </div>

        {/* Right: Verification Verdict & Security Scorecard */}
        <div className="lg:col-span-6 bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                Verification Verdict & Audit Report
              </h3>
              <span className="text-[11px] font-mono text-slate-500">
                Engine: CloudGuard CSPM Core
              </span>
            </div>

            {/* Verdict Status Card */}
            {isCompliant ? (
              <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-lg p-4 flex items-start gap-3">
                <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-bold text-emerald-300 flex items-center gap-2">
                    PASSED: SECURE & COMPLIANT
                    <span className="text-xs font-mono font-bold bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800">
                      100 / 100
                    </span>
                  </div>
                  <p className="text-xs text-emerald-400/90 leading-relaxed">
                    All security rules passed successfully. Configuration enforces encryption at rest, least privilege access boundaries, and complies with CIS AWS Benchmarks.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-rose-950/40 border border-rose-800/80 rounded-lg p-4 flex items-start gap-3">
                <ShieldAlert className="w-8 h-8 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-bold text-rose-300 flex items-center gap-2">
                    FAILED: MISCONFIGURATIONS DETECTED
                    <span className="text-xs font-mono font-bold bg-rose-950 text-rose-400 px-2 py-0.5 rounded border border-rose-800">
                      {verificationResult?.summary.postureScore} / 100
                    </span>
                  </div>
                  <p className="text-xs text-rose-300/90 leading-relaxed">
                    Identified <strong className="text-white">{verificationResult?.summary.totalFindings}</strong> security violation(s) including <strong className="text-rose-400">{verificationResult?.summary.criticalCount} Critical</strong> risk(s).
                  </p>
                </div>
              </div>
            )}

            {/* Detailed Findings Breakdown */}
            <div className="mt-4 space-y-2">
              <div className="text-xs font-semibold text-slate-300">
                Rule Verifications ({verificationResult?.findings.length || 0} Failed, {verificationResult?.passedChecks.length || 0} Passed)
              </div>

              {/* Failed Rules */}
              {verificationResult?.findings.map((f) => (
                <div
                  key={f.id}
                  className="p-3 bg-slate-950 border border-rose-900/40 rounded space-y-1.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span className="font-semibold text-slate-200">{f.title}</span>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950/80 px-1.5 py-0.2 rounded border border-rose-800">
                      {f.severity}
                    </span>
                  </div>

                  <div className="text-slate-400 text-[11px] pl-6">
                    {f.impact}
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono pl-6 pt-0.5">
                    <span>CVSS: <strong className="text-rose-400">{f.cvssScore}</strong></span>
                    <span>CIS: <strong className="text-slate-300">{f.compliance.cis?.[0] || 'N/A'}</strong></span>
                    <span>SOC 2: <strong className="text-slate-300">{f.compliance.soc2?.[0] || 'N/A'}</strong></span>
                  </div>

                  {/* Fix advice */}
                  <div className="pl-6 pt-1">
                    <div className="text-[11px] text-cyan-400 font-medium">Recommended Fix:</div>
                    <pre className="mt-1 p-2 bg-slate-900 border border-slate-800 rounded font-mono text-[10px] text-emerald-400 overflow-x-auto whitespace-pre">
                      {f.remediationCode}
                    </pre>
                  </div>
                </div>
              ))}

              {/* Passed Rules */}
              {verificationResult?.passedChecks.map((p) => (
                <div
                  key={p.id}
                  className="p-2 bg-slate-950/50 border border-slate-800/80 rounded flex items-center justify-between text-xs text-slate-400"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{p.title}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono">PASS</span>
                </div>
              ))}
            </div>
          </div>

          {/* Actions & Code Generation Footers */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">Generated Infrastructure-as-Code:</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyHcl}
                  className="text-[11px] text-slate-400 hover:text-cyan-400 flex items-center gap-1 font-mono"
                >
                  {copiedHcl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedHcl ? 'Copied HCL' : 'Copy HCL'}
                </button>
              </div>
            </div>

            <pre className="p-2.5 bg-slate-950 border border-slate-800 rounded font-mono text-[11px] text-slate-300 max-h-28 overflow-x-auto whitespace-pre">
              {currentGeneratedHcl}
            </pre>

            <button
              onClick={() => onLoadIntoScanner(currentGeneratedHcl, `${serviceType}_verified.tf`)}
              className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold rounded transition-colors flex items-center justify-center gap-1.5"
            >
              Open & Audit in Full IaC Scanner <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
