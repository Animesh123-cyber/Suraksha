import React, { useState } from 'react';
import { ScanResult, Finding } from '../types/cspm';
import { Copy, Check, Terminal, Download, ShieldCheck, ArrowRight, Code } from 'lucide-react';

interface RemediationViewProps {
  scanResult: ScanResult;
  onApplyRemediation: (finding: Finding) => void;
  onNavigateToScanner: () => void;
}

export const RemediationView: React.FC<RemediationViewProps> = ({
  scanResult,
  onApplyRemediation,
  onNavigateToScanner,
}) => {
  const { findings, summary } = scanResult;
  const [copiedPython, setCopiedPython] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);

  // Generate full Python Boto3 script based on active findings
  const pythonScript = `#!/usr/bin/env python3
"""
CloudGuard CSPM - Automated Blue Team AWS Remediation Script
Generated for: ${summary.scannedFile}
Violations Detected: ${summary.totalFindings} (Critical: ${summary.criticalCount}, High: ${summary.highCount})
Timestamp: ${summary.timestamp}
"""

import boto3
from botocore.exceptions import ClientError
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger("CloudGuardRemediator")

def main():
    logger.info("Starting automated CSPM Blue Team remediation workflow...")
    
    # 1. AWS S3 Remediation
    s3_client = boto3.client('s3')
${findings
  .filter((f) => f.resourceType.includes('s3'))
  .map(
    (f) => `    try:
        logger.info("Applying remediation for ${f.resourceName} (${f.ruleCode})...")
        ${f.boto3Remediation.split('\n').filter(l => !l.startsWith('import') && !l.startsWith('s3 =')).map(l => '        ' + l).join('\n')}
        logger.info("Successfully remediated S3 resource: ${f.resourceName}")
    except ClientError as e:
        logger.error(f"Failed to remediate ${f.resourceName}: {e}")
`
  )
  .join('\n')}

    # 2. AWS EC2 & Security Group Remediation
    ec2_client = boto3.client('ec2')
${findings
  .filter((f) => f.resourceType.includes('security_group') || f.resourceType.includes('instance'))
  .map(
    (f) => `    try:
        logger.info("Remediating EC2/SG ${f.resourceName} (${f.ruleCode})...")
        ${f.boto3Remediation.split('\n').filter(l => !l.startsWith('import') && !l.startsWith('ec2 =')).map(l => '        ' + l).join('\n')}
        logger.info("Successfully remediated: ${f.resourceName}")
    except ClientError as e:
        logger.error(f"Failed to remediate ${f.resourceName}: {e}")
`
  )
  .join('\n')}

    # 3. AWS RDS Database Remediation
    rds_client = boto3.client('rds')
${findings
  .filter((f) => f.resourceType.includes('db'))
  .map(
    (f) => `    try:
        logger.info("Remediating RDS instance ${f.resourceName}...")
        ${f.boto3Remediation.split('\n').filter(l => !l.startsWith('import') && !l.startsWith('rds =')).map(l => '        ' + l).join('\n')}
        logger.info("Successfully remediated RDS: ${f.resourceName}")
    except ClientError as e:
        logger.error(f"Failed to remediate ${f.resourceName}: {e}")
`
  )
  .join('\n')}

    # 4. AWS IAM Least Privilege Remediation
    iam_client = boto3.client('iam')
${findings
  .filter((f) => f.resourceType.includes('iam'))
  .map(
    (f) => `    try:
        logger.info("Enforcing least privilege for ${f.resourceName}...")
        ${f.boto3Remediation.split('\n').filter(l => !l.startsWith('import') && !l.startsWith('iam =') && !l.startsWith('#')).map(l => '        ' + l).join('\n')}
        logger.info("Successfully remediated IAM: ${f.resourceName}")
    except ClientError as e:
        logger.error(f"Failed to remediate ${f.resourceName}: {e}")
`
  )
  .join('\n')}

    logger.info("Blue Team remediation run complete. Please re-run scan to verify.")

if __name__ == '__main__':
    main()
`;

  // AWS CLI one-liners
  const cliCommands = findings
    .map((f) => `# ${f.title} (${f.resourceType}.${f.resourceName})\n${f.awsCliRemediation}`)
    .join('\n\n');

  const handleCopyPython = () => {
    navigator.clipboard.writeText(pythonScript);
    setCopiedPython(true);
    setTimeout(() => setCopiedPython(false), 2000);
  };

  const handleDownloadPython = () => {
    const blob = new Blob([pythonScript], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `remediate_aws_${Date.now()}.py`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyCli = () => {
    navigator.clipboard.writeText(cliCommands);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            Blue Team Auto-Remediator (Python & Boto3 SDK)
          </h2>
          <div className="text-xs text-slate-400 mt-0.5">
            Automatically generated executable Python script to remediate live AWS environments or attach to AWS Lambda for automated DevSecOps self-healing.
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyPython}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
          >
            {copiedPython ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedPython ? 'Copied' : 'Copy Python Script'}
          </button>
          <button
            onClick={handleDownloadPython}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download .py Script
          </button>
        </div>
      </div>

      {/* Python Boto3 Code Viewer */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300 font-mono">
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            remediate_aws_posture.py (Boto3 SDK)
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            {findings.length} auto-remediation routines generated
          </div>
        </div>

        <pre className="p-4 font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre max-h-[460px] leading-relaxed">
          {pythonScript}
        </pre>
      </div>

      {/* AWS CLI Quick Commands */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-200">AWS CLI Direct Terminal One-Liners</h3>
            <div className="text-[11px] text-slate-500">Run directly from your local terminal or AWS CloudShell</div>
          </div>
          <button
            onClick={handleCopyCli}
            className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1 font-mono"
          >
            {copiedCli ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            {copiedCli ? 'Copied CLI Commands' : 'Copy All Commands'}
          </button>
        </div>

        <pre className="p-3 bg-slate-950 border border-slate-800 rounded font-mono text-xs text-emerald-400 overflow-x-auto whitespace-pre max-h-60">
          {cliCommands || '# No active violations requiring CLI remediation.'}
        </pre>
      </div>
    </div>
  );
};
