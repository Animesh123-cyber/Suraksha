import React, { useState } from 'react';
import { ScanResult, WebhookConfig, WebhookDispatchRecord } from '../types/cspm';
import {
  formatSlackPayload,
  formatDiscordPayload,
  formatGenericPayload,
} from '../lib/webhookDispatcher';
import {
  Send,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Bell,
  Code,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';

interface WebhookViewProps {
  scanResult: ScanResult;
  webhookConfig: WebhookConfig;
  setWebhookConfig: React.Dispatch<React.SetStateAction<WebhookConfig>>;
  dispatchHistory: WebhookDispatchRecord[];
  onDispatchWebhook: (forceTest: boolean) => Promise<void>;
  isDispatching: boolean;
}

export const WebhookView: React.FC<WebhookViewProps> = ({
  scanResult,
  webhookConfig,
  setWebhookConfig,
  dispatchHistory,
  onDispatchWebhook,
  isDispatching,
}) => {
  const [copiedPayload, setCopiedPayload] = useState(false);
  const [activePreviewTab, setActivePreviewTab] = useState<'visual' | 'json'>('visual');

  const { findings, summary } = scanResult;

  // Generate payload preview based on platform
  const payloadObj =
    webhookConfig.platform === 'slack'
      ? formatSlackPayload(findings, summary)
      : webhookConfig.platform === 'discord'
      ? formatDiscordPayload(findings, summary)
      : formatGenericPayload(findings, summary);

  const payloadString = JSON.stringify(payloadObj, null, 2);

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(payloadString);
    setCopiedPayload(true);
    setTimeout(() => setCopiedPayload(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Configuration Header & Inputs */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Bell className="w-4 h-4 text-cyan-400" />
              Automated DevSecOps Webhook Alerting
            </h2>
            <div className="text-xs text-slate-400 mt-0.5">
              Instantly notify your Blue Team or SecOps on Slack, Discord, or SIEM when non-compliant IaC or cloud misconfigurations are detected.
            </div>
          </div>
        </div>

        {/* Form Inputs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Platform Selector */}
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-medium">Alert Destination Platform</label>
            <div className="grid grid-cols-3 gap-2">
              {(['slack', 'discord', 'generic'] as const).map((plat) => (
                <button
                  key={plat}
                  onClick={() => setWebhookConfig({ ...webhookConfig, platform: plat })}
                  className={`py-2 px-2 text-xs font-medium rounded border transition-colors capitalize ${
                    webhookConfig.platform === plat
                      ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {plat}
                </button>
              ))}
            </div>
          </div>

          {/* Webhook URL Input */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs text-slate-400 font-medium">Incoming Webhook URL</label>
              <span className="text-[11px] text-slate-500">Leave blank for dry-run simulation</span>
            </div>
            <input
              type="text"
              placeholder={
                webhookConfig.platform === 'slack'
                  ? 'https://hooks.slack.com/services/T.../B.../X...'
                  : webhookConfig.platform === 'discord'
                  ? 'https://discord.com/api/webhooks/.../...'
                  : 'https://api.yourdomain.com/webhooks/security'
              }
              value={webhookConfig.url}
              onChange={(e) => setWebhookConfig({ ...webhookConfig, url: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 placeholder-slate-600 outline-none focus:border-cyan-400 font-mono"
            />
          </div>
        </div>

        {/* Severity Threshold & Auto Trigger */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-medium">Minimum Severity Threshold to Alert</label>
            <select
              value={webhookConfig.minSeverity}
              onChange={(e) =>
                setWebhookConfig({ ...webhookConfig, minSeverity: e.target.value as any })
              }
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400"
            >
              <option value="CRITICAL">Critical Violations Only (P0 breaches)</option>
              <option value="HIGH">High & Critical Violations (Recommended)</option>
              <option value="MEDIUM">Medium, High & Critical Violations</option>
              <option value="LOW">All Findings (Verbose telemetry)</option>
            </select>
          </div>

          <div className="flex items-end justify-between gap-3">
            <button
              onClick={() => onDispatchWebhook(false)}
              disabled={isDispatching}
              className="flex-1 py-2 px-4 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              {isDispatching ? 'Transmitting Alert...' : 'Dispatch Alert to Channel'}
            </button>

            <button
              onClick={() => onDispatchWebhook(true)}
              disabled={isDispatching}
              className="py-2 px-3 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded transition-colors"
            >
              Simulate Dry-Run
            </button>
          </div>
        </div>
      </div>

      {/* Live Payload Preview & Visual Simulation */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg overflow-hidden">
        <div className="p-3 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-200">
              {webhookConfig.platform === 'slack'
                ? 'Slack Channel Feed Simulation'
                : webhookConfig.platform === 'discord'
                ? 'Discord Embed Feed Simulation'
                : 'Generic DevSecOps JSON Payload'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 p-0.5 rounded">
              <button
                onClick={() => setActivePreviewTab('visual')}
                className={`px-2 py-0.5 rounded text-[11px] ${
                  activePreviewTab === 'visual' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400'
                }`}
              >
                Visual Feed
              </button>
              <button
                onClick={() => setActivePreviewTab('json')}
                className={`px-2 py-0.5 rounded text-[11px] ${
                  activePreviewTab === 'json' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400'
                }`}
              >
                Raw JSON
              </button>
            </div>

            <button
              onClick={handleCopyPayload}
              className="text-slate-400 hover:text-cyan-400 flex items-center gap-1 text-[11px] ml-2"
            >
              {copiedPayload ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {copiedPayload ? 'Copied' : 'Copy Payload'}
            </button>
          </div>
        </div>

        <div className="p-5">
          {activePreviewTab === 'visual' ? (
            webhookConfig.platform === 'slack' ? (
              /* Slack Block Kit Visual Simulation */
              <div className="max-w-2xl mx-auto bg-[#1A1D21] border border-[#2C3136] rounded-lg p-4 font-sans text-white text-xs shadow-xl space-y-3">
                <div className="flex items-center gap-2 border-b border-[#2C3136] pb-2">
                  <div className="w-7 h-7 rounded bg-cyan-600 flex items-center justify-center font-bold text-white text-xs">
                    CG
                  </div>
                  <div>
                    <div className="font-bold text-sm text-white flex items-center gap-2">
                      CloudGuard CSPM Bot
                      <span className="text-[10px] bg-[#2C3136] text-slate-400 px-1 py-0.2 rounded">APP</span>
                    </div>
                    <div className="text-[10px] text-slate-400">Just now · DevSecOps Alert</div>
                  </div>
                </div>

                <div className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                  🛡️ CloudGuard CSPM: Security Policy Violations Detected
                </div>

                <p className="text-slate-300">
                  Automated DevSecOps Compliance Alert triggered on target <code className="text-cyan-300 font-mono bg-slate-950 px-1 rounded">{summary.scannedFile}</code>. Total misconfigurations: <strong className="text-rose-400">{summary.totalFindings}</strong>.
                </p>

                <div className="grid grid-cols-2 gap-2 bg-[#222529] p-3 rounded border border-[#2C3136]">
                  <div>
                    <span className="text-slate-400 text-[11px]">Posture Score:</span>
                    <div className="text-base font-mono font-bold text-amber-400">{summary.postureScore}/100</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Critical Violations:</span>
                    <div className="text-base font-mono font-bold text-rose-400">{summary.criticalCount}</div>
                  </div>
                </div>

                <div className="space-y-2 pt-1">
                  {findings.slice(0, 3).map((f) => (
                    <div key={f.id} className="p-2.5 bg-[#222529] rounded border border-[#2C3136] space-y-1">
                      <div className="font-semibold text-rose-300 flex items-center gap-1.5">
                        🚨 [{f.severity}] {f.title}
                      </div>
                      <div className="text-slate-400 text-[11px] font-mono">
                        Resource: <span className="text-cyan-400">{f.resourceType}.{f.resourceName}</span> (Line {f.lineNumber})
                      </div>
                      <div className="text-slate-300 text-[11px]">
                        CIS: <span className="text-slate-200">{f.compliance.cis?.join(', ') || 'N/A'}</span> · CVSS: <span className="text-rose-400">{f.cvssScore}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* Discord Embed Visual Simulation */
              <div className="max-w-2xl mx-auto bg-[#313338] border border-[#202225] rounded-lg p-4 font-sans text-white text-xs shadow-xl space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-cyan-600 flex items-center justify-center font-bold text-white text-xs shrink-0">
                    CG
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">CloudGuard CSPM Alert Bot</span>
                      <span className="text-[10px] bg-[#5865F2] text-white px-1 rounded font-semibold">BOT</span>
                      <span className="text-[10px] text-slate-400">Today at {new Date().toLocaleTimeString()}</span>
                    </div>

                    {/* Discord Embed with colored left border */}
                    <div className="border-l-4 border-rose-500 bg-[#2B2D31] rounded-r p-3 space-y-2.5">
                      <div className="font-bold text-sm text-cyan-400">
                        🛡️ Cloud Security Posture Management Alert
                      </div>
                      <p className="text-slate-300 text-xs">
                        Automated scan completed on <code className="bg-slate-900 px-1 rounded">{summary.scannedFile}</code>. Security posture score: <strong className="text-amber-400">{summary.postureScore}/100</strong>.
                      </p>

                      <div className="grid grid-cols-3 gap-2 bg-[#202225] p-2 rounded">
                        <div>
                          <div className="text-[10px] text-slate-400 font-semibold">Critical</div>
                          <div className="text-rose-400 font-bold font-mono">{summary.criticalCount}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-400 font-semibold">High</div>
                          <div className="text-amber-400 font-bold font-mono">{summary.highCount}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-400 font-semibold">Medium</div>
                          <div className="text-yellow-400 font-bold font-mono">{summary.mediumCount}</div>
                        </div>
                      </div>

                      <div className="space-y-2 pt-1">
                        {findings.slice(0, 3).map((f) => (
                          <div key={f.id} className="text-xs space-y-0.5">
                            <div className="font-semibold text-rose-300">
                              [{f.severity}] {f.title}
                            </div>
                            <div className="text-slate-400 text-[11px]">
                              Resource: <code className="text-slate-200">{f.resourceType}.{f.resourceName}</code> · CVSS: <strong className="text-rose-400">{f.cvssScore}</strong>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          ) : (
            <pre className="p-4 bg-slate-950 border border-slate-800 rounded font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre max-h-96">
              {payloadString}
            </pre>
          )}
        </div>
      </div>

      {/* Webhook Dispatch History Log */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-semibold text-slate-200 mb-3">
          Webhook Transmission Activity Log ({dispatchHistory.length})
        </h3>

        {dispatchHistory.length === 0 ? (
          <div className="text-xs text-slate-500 py-4 text-center">
            No webhooks dispatched yet. Click "Dispatch Alert to Channel" or "Simulate Dry-Run" above.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {dispatchHistory.map((rec) => (
              <div key={rec.id} className="py-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <span
                    className={`font-mono text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                      rec.status === 'SUCCESS'
                        ? 'bg-emerald-950/60 border-emerald-800 text-emerald-400'
                        : rec.status === 'SIMULATED'
                        ? 'bg-cyan-950/60 border-cyan-800 text-cyan-400'
                        : 'bg-rose-950/60 border-rose-800 text-rose-400'
                    }`}
                  >
                    {rec.status}
                  </span>
                  <span className="font-mono text-slate-300 uppercase">{rec.platform}</span>
                  <span className="text-slate-400 truncate max-w-sm">{rec.responseMessage}</span>
                </div>

                <div className="text-[11px] text-slate-500 font-mono">
                  {new Date(rec.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
