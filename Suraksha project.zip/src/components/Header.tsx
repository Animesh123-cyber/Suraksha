import React from 'react';
import { Download } from 'lucide-react';

interface HeaderProps {
  activeTab: 'dashboard' | 'verifier' | 'scanner' | 'compliance' | 'webhooks' | 'remediation';
  setActiveTab: (tab: 'dashboard' | 'verifier' | 'scanner' | 'compliance' | 'webhooks' | 'remediation') => void;
  onExportClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onExportClick,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2">
          <span className="inline-block w-2.5 h-2.5 rounded-sm bg-cyan-400"></span>
          CloudGuard CSPM
        </span>
      </div>

      {/* Zone 2: 5 clean single-line navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'dashboard' ? 'text-white border-b-2 border-cyan-400' : ''
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => setActiveTab('verifier')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'verifier' ? 'text-white border-b-2 border-cyan-400' : ''
          }`}
        >
          Enter & Verify
        </button>
        <button
          onClick={() => setActiveTab('scanner')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'scanner' ? 'text-white border-b-2 border-cyan-400' : ''
          }`}
        >
          IaC Scanner
        </button>
        <button
          onClick={() => setActiveTab('compliance')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'compliance' ? 'text-white border-b-2 border-cyan-400' : ''
          }`}
        >
          Compliance
        </button>
        <button
          onClick={() => setActiveTab('webhooks')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'webhooks' ? 'text-white border-b-2 border-cyan-400' : ''
          }`}
        >
          Webhooks
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onExportClick}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          Export Report
        </button>
      </div>
    </header>
  );
};
