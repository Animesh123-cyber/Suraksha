import React, { useState } from 'react';
import { ScanResult } from '../types/cspm';
import { generateHtmlAuditReport } from '../lib/reportGenerator';
import { X, Download, FileText, Code, Copy, Check } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  scanResult: ScanResult;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  scanResult,
}) => {
  const [copiedMd, setCopiedMd] = useState(false);

  if (!isOpen) return null;

  const { summary, findings } = scanResult;

  // Generate Markdown summary
  const markdownReport = `# CloudGuard CSPM Security Audit Report
**Target Infrastructure:** \`${summary.scannedFile}\`  
**Security Posture Score:** **${summary.postureScore}/100**  
**Audit Timestamp:** ${summary.timestamp}  

## Executive Summary
- **Total Resources Audited:** ${summary.totalResources}
- **Critical Violations:** ${summary.criticalCount}
- **High Violations:** ${summary.highCount}
- **Medium Violations:** ${summary.mediumCount}
- **Passed Checks:** ${summary.passedCount}

## Detected Misconfigurations (${findings.length})
${findings
  .map(
    (f, idx) => `
### ${idx + 1}. [${f.severity}] ${f.title}
- **Resource:** \`${f.resourceType}.${f.resourceName}\` (Line ${f.lineNumber})
- **CVSS Score:** ${f.cvssScore}
- **CIS Benchmark:** \`${f.compliance.cis?.join(', ') || 'N/A'}\`
- **Impact:** ${f.impact}
- **Remediation:** ${f.remediationAdvice}
\`\`\`hcl
${f.remediationCode}
\`\`\`
`
  )
  .join('\n')}
`;

  const handleDownloadHtml = () => {
    const html = generateHtmlAuditReport(scanResult);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cloudguard-cspm-report-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(scanResult, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cloudguard-findings-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(markdownReport);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-lg max-w-lg w-full overflow-hidden shadow-2xl">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Download className="w-4 h-4 text-cyan-400" />
            Export Security Audit & Compliance Report
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <p className="text-slate-400">
            Generate executive compliance reports detailing all vulnerability severities, CIS/SOC 2 metrics, and remediation diffs.
          </p>

          <div className="space-y-3">
            {/* Option 1: Standalone HTML */}
            <div
              onClick={handleDownloadHtml}
              className="p-3 bg-slate-950 border border-slate-800 hover:border-cyan-400/70 rounded-lg cursor-pointer transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-cyan-950/80 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-slate-200 group-hover:text-cyan-400 transition-colors">
                    Standalone HTML Report (.html)
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Self-contained, printable executive audit report with full CSS and charts
                  </div>
                </div>
              </div>
              <Download className="w-4 h-4 text-slate-400 group-hover:text-cyan-400" />
            </div>

            {/* Option 2: JSON SARIF / CSPM */}
            <div
              onClick={handleDownloadJson}
              className="p-3 bg-slate-950 border border-slate-800 hover:border-cyan-400/70 rounded-lg cursor-pointer transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-emerald-950/80 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                  <Code className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-slate-200 group-hover:text-cyan-400 transition-colors">
                    Structured Machine JSON (.json)
                  </div>
                  <div className="text-[11px] text-slate-500">
                    SARIF & DevSecOps pipeline automation schema for CI/CD integration
                  </div>
                </div>
              </div>
              <Download className="w-4 h-4 text-slate-400 group-hover:text-cyan-400" />
            </div>

            {/* Option 3: Copy Markdown */}
            <div
              onClick={handleCopyMarkdown}
              className="p-3 bg-slate-950 border border-slate-800 hover:border-cyan-400/70 rounded-lg cursor-pointer transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-purple-950/80 border border-purple-800/60 flex items-center justify-center text-purple-400">
                  {copiedMd ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </div>
                <div>
                  <div className="font-semibold text-slate-200 group-hover:text-cyan-400 transition-colors">
                    {copiedMd ? 'Copied to Clipboard!' : 'Copy Markdown Report'}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Formatted text for GitHub PR comments, Jira tickets, or incident docs
                  </div>
                </div>
              </div>
              <span className="text-[11px] text-slate-400">Copy</span>
            </div>
          </div>
        </div>

        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
