import React, { useState } from 'react';
import { Finding, ScanResult } from '../types/cspm';
import { SAMPLE_TEMPLATES } from '../lib/sampleTemplates';
import {
  Play,
  Upload,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Wand2,
  ChevronDown,
  Terminal,
  Filter,
  Search,
} from 'lucide-react';

interface IacScannerViewProps {
  sourceCode: string;
  setSourceCode: (code: string) => void;
  fileName: string;
  setFileName: (name: string) => void;
  scanResult: ScanResult;
  onRunScan: (codeToScan?: string) => void;
  selectedFinding: Finding | null;
  setSelectedFinding: (f: Finding | null) => void;
  onApplyRemediation: (finding: Finding) => void;
}

export const IacScannerView: React.FC<IacScannerViewProps> = ({
  sourceCode,
  setSourceCode,
  fileName,
  setFileName,
  scanResult,
  onRunScan,
  selectedFinding,
  setSelectedFinding,
  onApplyRemediation,
}) => {
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedSnippetId, setCopiedSnippetId] = useState<string | null>(null);
  const [activeRemediationTab, setActiveRemediationTab] = useState<'terraform' | 'boto3' | 'cli'>('terraform');

  const { findings, summary } = scanResult;

  // Filter findings
  const filteredFindings = findings.filter((f) => {
    const matchesSev = severityFilter === 'ALL' || f.severity === severityFilter;
    const matchesQuery =
      searchQuery === '' ||
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.resourceType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.resourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.ruleCode.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSev && matchesQuery;
  });

  // Calculate lines with findings for gutter highlighting
  const findingLines = new Set(findings.map((f) => f.lineNumber));

  const handleSelectTemplate = (templateId: string) => {
    const tpl = SAMPLE_TEMPLATES.find((t) => t.id === templateId);
    if (tpl) {
      setSourceCode(tpl.code);
      setFileName(`${tpl.id}.tf`);
      onRunScan(tpl.code);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          setSourceCode(text);
          setFileName(file.name);
          onRunScan(text);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleCopySnippet = (snippet: string, id: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedSnippetId(id);
    setTimeout(() => setCopiedSnippetId(null), 2000);
  };

  const lines = sourceCode.split('\n');

  return (
    <div className="space-y-4">
      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 rounded-lg p-3">
        {/* Template Selector & Upload */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Template:</span>
            <select
              onChange={(e) => handleSelectTemplate(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1.5 focus:border-cyan-400 outline-none"
            >
              {SAMPLE_TEMPLATES.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded cursor-pointer transition-colors">
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            Upload IaC (.tf, .json)
            <input type="file" accept=".tf,.json,.yaml,.yml" onChange={handleFileUpload} className="hidden" />
          </label>

          <button
            onClick={() => {
              setSourceCode('# Enter or paste your custom Terraform or AWS configuration:\n\n');
              setFileName('custom_input.tf');
            }}
            className="px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded transition-colors"
          >
            Clear / Enter Custom Code
          </button>

          <span className="text-xs text-slate-500 font-mono">
            Target: <span className="text-slate-300 font-semibold">{fileName}</span>
          </span>
        </div>

        {/* Scan Button & Quick Stat */}
        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>Score:</span>
            <span
              className={`font-mono font-bold ${
                summary.postureScore >= 80
                  ? 'text-emerald-400'
                  : summary.postureScore >= 50
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}
            >
              {summary.postureScore}/100
            </span>
          </div>

          <button
            onClick={() => onRunScan(sourceCode)}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors shadow"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Verify Security Posture
          </button>
        </div>
      </div>

      {/* Main Split Screen: Code Editor (Left) & Findings Inspector (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[720px]">
        {/* Left: Code Editor with Line Numbers */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-lg flex flex-col overflow-hidden">
          {/* Editor Header */}
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400 font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700 inline-block"></span>
              {fileName} ({lines.length} lines)
            </div>
            <div className="text-slate-500 text-[11px]">
              {findingLines.size} flagged lines
            </div>
          </div>

          {/* Editor Body */}
          <div className="flex-1 flex overflow-hidden font-mono text-xs">
            {/* Line Number Gutter */}
            <div className="w-12 bg-slate-900/40 border-r border-slate-800/80 select-none py-3 overflow-hidden text-right pr-2 text-slate-600 font-mono text-[11px] space-y-[4px]">
              {lines.map((_, idx) => {
                const lineNum = idx + 1;
                const isViolating = findingLines.has(lineNum);
                return (
                  <div
                    key={lineNum}
                    className={`h-[18px] leading-[18px] ${
                      isViolating ? 'text-rose-400 font-bold bg-rose-950/40 rounded px-0.5' : ''
                    }`}
                  >
                    {lineNum}
                  </div>
                );
              })}
            </div>

            {/* Editable Textarea Overlay with exact line-height alignment */}
            <div className="flex-1 relative overflow-auto p-3">
              <textarea
                value={sourceCode}
                onChange={(e) => setSourceCode(e.target.value)}
                spellCheck={false}
                className="w-full h-full bg-transparent text-slate-200 outline-none resize-none font-mono text-xs leading-[18px] whitespace-pre"
                style={{ tabSize: 2 }}
              />
            </div>
          </div>
        </div>

        {/* Right: Findings Inspector & Remediation Panel */}
        <div className="lg:col-span-5 bg-slate-900/70 border border-slate-800 rounded-lg flex flex-col overflow-hidden">
          {/* Header & Filter Controls */}
          <div className="p-3 border-b border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-slate-300">
                Security Violations ({filteredFindings.length} / {findings.length})
              </h2>
              <span className="text-[11px] text-slate-500 font-mono">
                {summary.criticalCount} Critical · {summary.highCount} High
              </span>
            </div>

            {/* Filter pills & Search */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-3 h-3 text-slate-500 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter by rule, resource, or title..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded pl-7 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 outline-none focus:border-cyan-400"
                />
              </div>

              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded px-2 py-1 outline-none focus:border-cyan-400"
              >
                <option value="ALL">All Severities</option>
                <option value="CRITICAL">Critical Only</option>
                <option value="HIGH">High Only</option>
                <option value="MEDIUM">Medium Only</option>
              </select>
            </div>
          </div>

          {/* Findings List & Detail */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 p-3 space-y-3">
            {filteredFindings.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <div className="text-xs font-semibold text-white">No Matching Violations</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  The infrastructure matches all selected filters.
                </div>
              </div>
            ) : (
              filteredFindings.map((finding) => {
                const isSelected = selectedFinding?.id === finding.id;

                return (
                  <div
                    key={finding.id}
                    className={`rounded-lg border transition-all ${
                      isSelected
                        ? 'border-cyan-500/80 bg-slate-950/80'
                        : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                    }`}
                  >
                    {/* Finding Header */}
                    <div
                      onClick={() => setSelectedFinding(isSelected ? null : finding)}
                      className="p-3 cursor-pointer flex items-start justify-between gap-2"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                              finding.severity === 'CRITICAL'
                                ? 'bg-rose-950/70 border-rose-800 text-rose-300'
                                : finding.severity === 'HIGH'
                                ? 'bg-amber-950/70 border-amber-800 text-amber-300'
                                : 'bg-yellow-950/70 border-yellow-800 text-yellow-300'
                            }`}
                          >
                            {finding.severity}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            {finding.ruleCode}
                          </span>
                          <span className="text-[11px] font-mono text-cyan-400">
                            Line {finding.lineNumber}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-200 leading-snug">
                          {finding.title}
                        </h4>
                        <div className="text-[11px] font-mono text-slate-500">
                          {finding.resourceType}.{finding.resourceName}
                        </div>
                      </div>

                      <ChevronDown
                        className={`w-4 h-4 text-slate-500 shrink-0 transition-transform ${
                          isSelected ? 'rotate-180 text-cyan-400' : ''
                        }`}
                      />
                    </div>

                    {/* Expanded Detail Panel */}
                    {isSelected && (
                      <div className="border-t border-slate-800/80 p-3 space-y-3 bg-slate-950/60 text-xs">
                        {/* CVSS & Compliance badges */}
                        <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-mono">
                          <span>CVSS Score: <strong className="text-rose-400">{finding.cvssScore}</strong></span>
                          <span>CIS: <strong className="text-slate-200">{finding.compliance.cis?.[0] || 'N/A'}</strong></span>
                          <span>SOC 2: <strong className="text-slate-200">{finding.compliance.soc2?.[0] || 'N/A'}</strong></span>
                        </div>

                        {/* Impact */}
                        <div>
                          <span className="text-slate-400 font-semibold block text-[11px]">Security Impact:</span>
                          <p className="text-slate-300 text-xs mt-0.5">{finding.impact}</p>
                        </div>

                        {/* Advice */}
                        <div>
                          <span className="text-slate-400 font-semibold block text-[11px]">Remediation Advice:</span>
                          <p className="text-slate-300 text-xs mt-0.5">{finding.remediationAdvice}</p>
                        </div>

                        {/* Remediation Selector (Terraform / Python Boto3 / CLI) */}
                        <div className="space-y-1.5 pt-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded p-0.5">
                              <button
                                onClick={() => setActiveRemediationTab('terraform')}
                                className={`px-2 py-0.5 text-[10px] rounded font-mono ${
                                  activeRemediationTab === 'terraform'
                                    ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                                    : 'text-slate-500 hover:text-slate-300'
                                }`}
                              >
                                Terraform Fix
                              </button>
                              <button
                                onClick={() => setActiveRemediationTab('boto3')}
                                className={`px-2 py-0.5 text-[10px] rounded font-mono ${
                                  activeRemediationTab === 'boto3'
                                    ? 'bg-purple-500/20 text-purple-300 font-semibold'
                                    : 'text-slate-500 hover:text-slate-300'
                                }`}
                              >
                                Python Boto3
                              </button>
                              <button
                                onClick={() => setActiveRemediationTab('cli')}
                                className={`px-2 py-0.5 text-[10px] rounded font-mono ${
                                  activeRemediationTab === 'cli'
                                    ? 'bg-blue-500/20 text-blue-300 font-semibold'
                                    : 'text-slate-500 hover:text-slate-300'
                                }`}
                              >
                                AWS CLI
                              </button>
                            </div>

                            <button
                              onClick={() => {
                                const snippet =
                                  activeRemediationTab === 'terraform'
                                    ? finding.remediationCode
                                    : activeRemediationTab === 'boto3'
                                    ? finding.boto3Remediation
                                    : finding.awsCliRemediation;
                                handleCopySnippet(snippet, finding.id);
                              }}
                              className="text-[11px] text-slate-400 hover:text-cyan-400 flex items-center gap-1"
                            >
                              {copiedSnippetId === finding.id ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-400" /> Copied
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3" /> Copy
                                </>
                              )}
                            </button>
                          </div>

                          <pre className="p-2.5 bg-slate-950 border border-slate-800 rounded font-mono text-[11px] text-emerald-400 overflow-x-auto whitespace-pre">
                            {activeRemediationTab === 'terraform'
                              ? finding.remediationCode
                              : activeRemediationTab === 'boto3'
                              ? finding.boto3Remediation
                              : finding.awsCliRemediation}
                          </pre>
                        </div>

                        {/* 1-Click Auto Remediation Button */}
                        <div className="pt-2">
                          <button
                            onClick={() => onApplyRemediation(finding)}
                            className="w-full flex items-center justify-center gap-2 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-semibold rounded text-xs transition-colors"
                          >
                            <Wand2 className="w-3.5 h-3.5" />
                            Apply 1-Click Auto-Remediation
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
