import React, { useState } from 'react';
import { ScanResult, ComplianceFrameworkSummary, Finding } from '../types/cspm';
import { CheckCircle2, XCircle, Shield, FileText, ChevronRight } from 'lucide-react';

interface ComplianceViewProps {
  scanResult: ScanResult;
  onSelectFinding: (finding: Finding) => void;
  onNavigateToScanner: () => void;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({
  scanResult,
  onSelectFinding,
  onNavigateToScanner,
}) => {
  const { compliance, findings } = scanResult;
  const [selectedFrameworkName, setSelectedFrameworkName] = useState<string>(
    compliance[0]?.name || 'CIS AWS Foundations Benchmark'
  );
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'FAIL' | 'PASS'>('ALL');

  const currentFramework =
    compliance.find((c) => c.name === selectedFrameworkName) || compliance[0];

  if (!currentFramework) {
    return <div className="text-slate-400">No compliance data available.</div>;
  }

  const filteredControls = currentFramework.controls.filter((ctrl) => {
    if (statusFilter === 'ALL') return true;
    return ctrl.status === statusFilter;
  });

  const scoreColor =
    currentFramework.scorePercentage >= 80
      ? 'text-emerald-400'
      : currentFramework.scorePercentage >= 50
      ? 'text-amber-400'
      : 'text-rose-400';

  return (
    <div className="space-y-6">
      {/* Framework Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800">
        {compliance.map((fw) => {
          const isActive = fw.name === selectedFrameworkName;
          return (
            <button
              key={fw.name}
              onClick={() => setSelectedFrameworkName(fw.name)}
              className={`px-3.5 py-2 text-xs font-medium rounded-t transition-colors whitespace-nowrap flex items-center gap-2 ${
                isActive
                  ? 'bg-slate-900 text-white border-b-2 border-cyan-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              {fw.name}
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                fw.scorePercentage >= 80
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                  : 'bg-rose-950/60 text-rose-400 border border-rose-800/40'
              }`}>
                {fw.scorePercentage}%
              </span>
            </button>
          );
        })}
      </div>

      {/* Framework Summary Header */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-5 flex flex-wrap items-center justify-between gap-5">
        <div className="space-y-1 max-w-xl">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-100">{currentFramework.name}</h2>
            <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              {currentFramework.version}
            </span>
          </div>
          <p className="text-xs text-slate-400">{currentFramework.description}</p>
        </div>

        {/* Score & Control Counters */}
        <div className="flex items-center gap-6">
          <div className="text-center">
            <div className="text-[11px] text-slate-500 uppercase tracking-wider">Compliance Rate</div>
            <div className={`text-3xl font-mono font-bold tabular-nums ${scoreColor}`}>
              {currentFramework.scorePercentage}%
            </div>
          </div>

          <div className="border-l border-slate-800 pl-6 flex items-center gap-4 text-xs font-mono">
            <div>
              <div className="text-emerald-400 font-semibold text-base">{currentFramework.passedControls}</div>
              <div className="text-slate-500 text-[11px]">Controls Passed</div>
            </div>
            <div>
              <div className="text-rose-400 font-semibold text-base">{currentFramework.failedControls}</div>
              <div className="text-slate-500 text-[11px]">Controls Failed</div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls Audit Table */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-lg overflow-hidden">
        {/* Table Filter Toolbar */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="font-semibold text-slate-300">
            Control Requirements ({filteredControls.length} of {currentFramework.totalControls})
          </div>

          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 p-0.5 rounded">
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                statusFilter === 'ALL' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Controls
            </button>
            <button
              onClick={() => setStatusFilter('FAIL')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                statusFilter === 'FAIL' ? 'bg-rose-950/80 text-rose-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Failed ({currentFramework.failedControls})
            </button>
            <button
              onClick={() => setStatusFilter('PASS')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                statusFilter === 'PASS' ? 'bg-emerald-950/80 text-emerald-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Passed ({currentFramework.passedControls})
            </button>
          </div>
        </div>

        {/* Control Rows */}
        <div className="divide-y divide-slate-800/80">
          {filteredControls.map((ctrl) => {
            const isFailed = ctrl.status === 'FAIL';
            const matchedFindings = findings.filter((f) => ctrl.findingIds.includes(f.id));

            return (
              <div key={ctrl.id} className="p-4 hover:bg-slate-800/30 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {ctrl.id}
                      </span>
                      <span className="text-sm font-semibold text-slate-200">
                        {ctrl.title}
                      </span>
                    </div>

                    {isFailed && matchedFindings.length > 0 && (
                      <div className="mt-2.5 pl-3 border-l-2 border-rose-500/50 space-y-1.5">
                        <div className="text-[11px] text-rose-400 font-medium">
                          Failed by {matchedFindings.length} misconfigured resource(s):
                        </div>
                        {matchedFindings.map((f) => (
                          <div
                            key={f.id}
                            onClick={() => {
                              onSelectFinding(f);
                              onNavigateToScanner();
                            }}
                            className="flex items-center justify-between text-xs bg-slate-950/80 border border-slate-800/80 p-2 rounded hover:border-cyan-500/50 cursor-pointer transition-colors"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950/60 px-1.5 py-0.2 rounded border border-rose-800">
                                {f.severity}
                              </span>
                              <span className="text-slate-300 font-mono text-[11px]">
                                {f.resourceType}.{f.resourceName}
                              </span>
                              <span className="text-slate-500 text-[11px]">
                                (Line {f.lineNumber})
                              </span>
                            </div>
                            <span className="text-cyan-400 text-xs flex items-center gap-1">
                              View in IaC <ChevronRight className="w-3 h-3" />
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="shrink-0 flex items-center gap-1.5">
                    {isFailed ? (
                      <span className="flex items-center gap-1.5 text-xs font-medium text-rose-400 bg-rose-950/40 border border-rose-800/60 px-2.5 py-1 rounded">
                        <XCircle className="w-3.5 h-3.5" /> Non-Compliant
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 px-2.5 py-1 rounded">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
