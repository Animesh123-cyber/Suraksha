import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { runCspmScan } from './src/lib/complianceEngine.ts';
import { dispatchWebhookAlert } from './src/lib/webhookDispatcher.ts';
import { generateHtmlAuditReport } from './src/lib/reportGenerator.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'CloudGuard CSPM & Compliance Automator',
    timestamp: new Date().toISOString(),
  });
});

// Run CSPM scan endpoint
app.post('/api/scan', (req: Request, res: Response) => {
  try {
    const { code, filename = 'main.tf' } = req.body;
    if (!code || typeof code !== 'string') {
      return res.status(400).json({ error: 'Code content must be provided as a string' });
    }

    const scanResult = runCspmScan(code, filename);
    return res.json(scanResult);
  } catch (err: any) {
    console.error('Scan error:', err);
    return res.status(500).json({ error: err.message || 'Internal scan failure' });
  }
});

// Webhook dispatch endpoint (avoids browser CORS issues when posting to Slack or Discord)
app.post('/api/webhook/dispatch', async (req: Request, res: Response) => {
  try {
    const { webhookConfig, findings, summary, forceTestMode = false } = req.body;
    if (!webhookConfig) {
      return res.status(400).json({ error: 'Webhook configuration is required' });
    }

    const result = await dispatchWebhookAlert(webhookConfig, findings || [], summary, forceTestMode);
    return res.json(result);
  } catch (err: any) {
    console.error('Webhook error:', err);
    return res.status(500).json({
      error: err.message || 'Failed to dispatch webhook',
      status: 'FAILED',
    });
  }
});

// Export HTML report endpoint
app.post('/api/report/html', (req: Request, res: Response) => {
  try {
    const { scanResult } = req.body;
    if (!scanResult || !scanResult.summary) {
      return res.status(400).json({ error: 'Valid scanResult object required' });
    }

    const html = generateHtmlAuditReport(scanResult);
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="cspm-audit-report-${Date.now()}.html"`);
    return res.send(html);
  } catch (err: any) {
    console.error('Report error:', err);
    return res.status(500).json({ error: err.message || 'Failed to generate report' });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Mount Vite middleware in development
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CloudGuard CSPM server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
